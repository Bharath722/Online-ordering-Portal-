<?php
$referrer = $_SERVER['HTTP_REFERER'];
if (!preg_match("index.html",$referrer)) {
header('Location: http://www.smartbanking.in');
} ;
//create variables
$name = $_POST['name'];
$email = $_POST['email'];
$sub = $_POST['subject'];
$msg = $_POST['message'];
//creat email
$to = "vyan.publications@gmail.com";
$header = "From : $email";
mail($to,$sub,$msg,$header);
header("location:index.html");
?>