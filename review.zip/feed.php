<?php
//create variables
$name = $_POST['name'];
$user = $_POST['email'];
$sub = $_POST['subject'];
$msg = $_POST['message'];
//create email
$to = "vyan.publications@gmail.com";
$header = "From : $user";
mail($to,$sub,$msg,$header);
header("location:index.html");
?>